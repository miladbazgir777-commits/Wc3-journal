# WC3 Journal — native Android project

A private, offline-first WebView application. Its assets/index.html is a clean edition of the Warcraft III Preference Codex (V9 functionality), with **no imported comparisons, cups, Faction Wars, snapshots, or personal preferences**. The 72-entry roster and game mechanics are built-in reference data, not saved user results.

## Build the installable APK

Requirements: Android Studio with Android SDK Platform 35, Android SDK Build Tools, JDK 17 and Internet access to download Gradle/Android Gradle Plugin dependencies. This environment did not have the Android SDK or a compatible APK toolchain, so **no compiled APK is included and a device installation has not been tested**.

1. In Android Studio choose **Open** and select the `WC3Journal_AndroidStudio` directory.
2. If prompted, generate a standard Gradle wrapper for version 8.7, or select an installed Gradle 8.7 distribution. (A Gradle-wrapper JAR cannot be bundled in this offline environment.)
3. Let Gradle sync and install missing SDK 35 components if Android Studio prompts.
4. Select **Build → Build APK(s)**. The debug APK appears at `app/build/outputs/apk/debug/app-debug.apk`.
5. Transfer the APK to your Android phone and install it, allowing installation from your file manager when Android asks.

Alternatively, the included `.github/workflows/build-android.yml` can build the debug APK using GitHub Actions without installing Android Studio. Upload the project **contents (not its parent folder)** to the root of a GitHub repository, run **Actions → Build Android APK → Run workflow**, then download the `WC3-Journal-APK` workflow artifact (unzip it to obtain the installable `.apk`). This requires a GitHub account and network access.

`app/src/main/assets/index.html` can be updated independently with another compatible journal HTML as long as its native bridge functions are preserved.

## Android data location and import/export

- Main state: Android's private internal storage, `getFilesDir()/journal-state.json`, typically `/data/user/0/com.des.wc3journal/files/journal-state.json` (actual path is OS-controlled and is not normally available to file managers).
- Automatic snapshots: `getFilesDir()/journal-snapshots.json`.
- Secondary localStorage data also exists inside Android System WebView's app sandbox. Main state is read from the private JSON file first.
- No storage permission required. Import uses Android's document picker; Export JSON and Export HTML use `ACTION_CREATE_DOCUMENT` and allow you to choose a user-visible file location.
- **Import JSON** accepts earlier Codex V6–V9 schema-1 backups for comparisons and cup brackets. Faction Wars are supported when present; old versions will not understand new war data.
- **Import old HTML** extracts only the `stateSeed` and optional `assetSeed` JSON from V6–V9 portable standalone HTML exports, without executing code from the imported file. If a previous HTML only stored progress in its browser localStorage and does not embed data, open that older app and export JSON instead.
- All imports are explicit and opt-in; the shipped app contains none of the user's earlier progress.
- Reinstalling after uninstall or tapping Android **Clear storage** destroys this private data. Android OS cloud backup is explicitly disabled to ensure a fresh install is empty; export JSON regularly.
- Imported image bulk selection uses Android's document picker. `webkitdirectory` folder-selection may not be supported by the installed Android System WebView; select multiple icons instead.

## Security / scope

The JS bridge is exposed only to a locally bundled asset. External navigation is opened in the system browser, not in this bridge-enabled WebView. `android:allowBackup=false`; HTTPS-only network resources, with optional online icon fetching disabled by default. No trackers or remote data sync.

Launcher icon uses the exact image supplied for this project, resized into five screen-density variants.
